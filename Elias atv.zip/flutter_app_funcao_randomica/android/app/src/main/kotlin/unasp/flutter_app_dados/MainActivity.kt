package unasp.flutter_app_dados

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
